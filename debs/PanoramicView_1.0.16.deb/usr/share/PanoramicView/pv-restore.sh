#!/bin/sh
# PanoramicView 救援脚本：恢复官方 dylib，移除补丁
set -u
if command -v jbroot >/dev/null 2>&1; then BASE=""; else BASE=/var/jb; fi
D="$BASE/Library/MobileSubstrate/DynamicLibraries"
if [ -f "$D/PanoramicView.dylib.official" ]; then
    cp -f "$D/PanoramicView.dylib.official" "$D/PanoramicView.dylib"
    echo "已恢复官方 PanoramicView.dylib"
else
    echo "未找到备份，请手动删除 $D/PanoramicView.dylib 与 .plist"
fi
rm -f "$D/PanoramicView.dylib.patched" 2>/dev/null || true
if command -v ldid >/dev/null 2>&1; then
    ldid -S "$D/PanoramicView.dylib" 2>/dev/null || true
fi
killall -9 SpringBoard 2>/dev/null || true
